//Task: sign
//Author: Galina Momcheva

#include <iostream>

using namespace std;

int main () {
 //opisanie na promenliwiti za trite ceni
 int cena1, cena2, cena3;

 //pomoshtni promenliwi 
 int posl_cena1, nach_cena2, posl_cena2, nach_cena3, posl_cena3;

 cin >> cena1 >> cena2 >> cena3;

 //posledna cifra na pyrvata cena
 posl_cena1 = cena1 % 10;

 //pyrvata cifra na vtorata cena
 nach_cena2 = cena2 / 10;

//poslednata cifra na vtorata cena
 posl_cena2 = cena2 % 10;

//pyrwata cifra na tretata cena
nach_cena3 = cena3 / 10;

// poslednata cifra na tretata cena
posl_cena3 = cena3 % 10;

// otpechatva se pyrwata cena
 cout <<cena1;

 // otpechatva se neobhodimoto ot vtorata cena
 if (posl_cena1 == nach_cena2)
    cout << '\'' << posl_cena2;
 else
    cout << nach_cena2 << posl_cena2;

 // otpechatva se neobhodimoto ot tretata cena
 if (posl_cena2 == nach_cena3)
    cout << '\'' << posl_cena3;
 else
    cout << nach_cena3 << posl_cena3;

cout << endl;

return 0;
}
