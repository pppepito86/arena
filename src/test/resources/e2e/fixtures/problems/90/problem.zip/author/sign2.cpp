//Task: sign
//Author: Galina Momcheva

#include <iostream>

using namespace std;

int main () {
 //opisanie na promenliwiti za trite ceni
 int cena1, cena2, cena3;

 cin >> cena1 >> cena2 >> cena3;


// otpechatva se pyrwata cena
 cout <<cena1;

 // otpechatva se neobhodimoto ot vtorata cena
 if (cena1 % 10 == cena2 / 10)
    cout << '\'' << cena2 % 10;
 else
    cout << cena2 / 10 << cena2 % 10;

 // otpechatva se neobhodimoto ot tretata cena
 if (cena2 % 10 == cena3 / 10)
    cout << '\'' << cena3 % 10;
 else
    cout << cena3 / 10 << cena3 % 10;

cout << endl;

return 0;
}
